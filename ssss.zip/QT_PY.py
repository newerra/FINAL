from PyQt5 import QtCore, QtGui, QtWidgets


class BegF(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("Бег")
        MainWindow.resize(590, 497)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(120, 122, 61, 20))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(120, 149, 61, 20))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(120, 176, 61, 20))
        self.label_3.setObjectName("label_3")
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(180, 118, 261, 121))
        self.widget.setObjectName("widget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.widget)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.lineEdit_3 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.verticalLayout.addWidget(self.lineEdit_3)
        self.lineEdit = QtWidgets.QLineEdit(self.widget)
        self.lineEdit.setObjectName("lineEdit")
        self.verticalLayout.addWidget(self.lineEdit)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.verticalLayout.addWidget(self.lineEdit_2)
        self.verticalLayout_2.addLayout(self.verticalLayout)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pushButton = QtWidgets.QPushButton(self.widget)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.widget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.horizontalLayout.addWidget(self.pushButton_2)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 590, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Бег"))
        self.label.setText(_translate("MainWindow", "  Калории"))
        self.label_2.setText(_translate("MainWindow", "Растояние"))
        self.label_3.setText(_translate("MainWindow", "    Время"))
        self.pushButton.setText(_translate("MainWindow", "Вычислить"))
        self.pushButton_2.setText(_translate("MainWindow", "Сбросить"))


class FoodF(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("Еда")
        MainWindow.resize(585, 501)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.layoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.layoutWidget.setGeometry(QtCore.QRect(110, 310, 281, 41))
        self.layoutWidget.setObjectName("layoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.layoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.vicheslit = QtWidgets.QPushButton(self.layoutWidget)
        self.vicheslit.setObjectName("vicheslit")
        self.horizontalLayout.addWidget(self.vicheslit)
        self.sbros = QtWidgets.QPushButton(self.layoutWidget)
        self.sbros.setObjectName("sbros")
        self.horizontalLayout.addWidget(self.sbros)
        self.layoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.layoutWidget_2.setGeometry(QtCore.QRect(110, 160, 281, 151))
        self.layoutWidget_2.setObjectName("layoutWidget_2")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.layoutWidget_2)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.produkt = QtWidgets.QComboBox(self.layoutWidget_2)
        self.produkt.setObjectName("produkt")
        self.verticalLayout.addWidget(self.produkt)
        self.grammovka = QtWidgets.QLineEdit(self.layoutWidget_2)
        self.grammovka.setObjectName("grammovka")
        self.verticalLayout.addWidget(self.grammovka)
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(50, 250, 61, 31))
        self.label_6.setObjectName("label_6")
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(110, 130, 281, 31))
        self.widget.setObjectName("widget")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.widget)
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.belki = QtWidgets.QLCDNumber(self.widget)
        self.belki.setObjectName("belki")
        self.horizontalLayout_2.addWidget(self.belki)
        self.zhiri = QtWidgets.QLCDNumber(self.widget)
        self.zhiri.setObjectName("zhiri")
        self.horizontalLayout_2.addWidget(self.zhiri)
        self.uglevodi = QtWidgets.QLCDNumber(self.widget)
        self.uglevodi.setObjectName("uglevodi")
        self.horizontalLayout_2.addWidget(self.uglevodi)
        self.kalorii = QtWidgets.QLCDNumber(self.widget)
        self.kalorii.setObjectName("kalorii")
        self.horizontalLayout_2.addWidget(self.kalorii)
        self.widget1 = QtWidgets.QWidget(self.centralwidget)
        self.widget1.setGeometry(QtCore.QRect(110, 100, 281, 31))
        self.widget1.setObjectName("widget1")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout(self.widget1)
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label = QtWidgets.QLabel(self.widget1)
        self.label.setObjectName("label")
        self.horizontalLayout_3.addWidget(self.label)
        self.label_2 = QtWidgets.QLabel(self.widget1)
        self.label_2.setObjectName("label_2")
        self.horizontalLayout_3.addWidget(self.label_2)
        self.label_4 = QtWidgets.QLabel(self.widget1)
        self.label_4.setObjectName("label_4")
        self.horizontalLayout_3.addWidget(self.label_4)
        self.label_3 = QtWidgets.QLabel(self.widget1)
        self.label_3.setObjectName("label_3")
        self.horizontalLayout_3.addWidget(self.label_3)
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(50, 190, 61, 31))
        self.label_5.setObjectName("label_5")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Еда"))
        self.vicheslit.setText(_translate("MainWindow", "Вычислить"))
        self.sbros.setText(_translate("MainWindow", "Сброс"))
        self.label_6.setText(_translate("MainWindow", "Граммовка"))
        self.label.setText(_translate("MainWindow", "    Белки"))
        self.label_2.setText(_translate("MainWindow", "     Жиры"))
        self.label_4.setText(_translate("MainWindow", "  Углеводы"))
        self.label_3.setText(_translate("MainWindow", "   Калории"))
        self.label_5.setText(_translate("MainWindow", "   Продукт"))


class MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("Меню")
        MainWindow.resize(500, 500)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.textEdit = QtWidgets.QTextEdit(self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(10, 10, 250, 80))
        self.textEdit.setFocusPolicy(QtCore.Qt.NoFocus)
        self.textEdit.setObjectName("textEdit")
        self.layoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.layoutWidget.setGeometry(QtCore.QRect(10, 90, 250, 80))
        self.layoutWidget.setObjectName("layoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.layoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.sport = QtWidgets.QPushButton(self.layoutWidget)
        self.sport.setEnabled(True)
        self.sport.setObjectName("sport")
        self.horizontalLayout.addWidget(self.sport)
        self.food = QtWidgets.QPushButton(self.layoutWidget)
        self.food.setObjectName("food")
        self.horizontalLayout.addWidget(self.food)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(10, 150, 250, 23))
        self.pushButton.setObjectName("pushButton")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Меню"))
        self.textEdit.setHtml(_translate("MainWindow",
                                         "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                         "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                         "p, li { white-space: pre-wrap; }\n"
                                         "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
                                         "<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:20pt; font-weight:600;\">Калькулятор Ккалорий</span></p></body></html>"))
        self.sport.setText(_translate("MainWindow", "Спорт"))
        self.food.setText(_translate("MainWindow", "Еда"))
        self.pushButton.setText(_translate("MainWindow", "Перевод калорий в граммы"))


class PerevodF(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("Перевод грамм/ккалл")
        MainWindow.resize(150, 150)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(20, 10, 50, 50))
        self.widget.setObjectName("widget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.widget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.lineEdit = QtWidgets.QLineEdit(self.widget)
        self.lineEdit.setObjectName("lineEdit")
        self.verticalLayout.addWidget(self.lineEdit)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.verticalLayout.addWidget(self.lineEdit_2)
        self.widget1 = QtWidgets.QWidget(self.centralwidget)
        self.widget1.setGeometry(QtCore.QRect(170, 10, 61, 51))
        self.widget1.setObjectName("widget1")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.widget1)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label = QtWidgets.QLabel(self.widget1)
        self.label.setObjectName("label")
        self.verticalLayout_2.addWidget(self.label)
        self.label_2 = QtWidgets.QLabel(self.widget1)
        self.label_2.setObjectName("label_2")
        self.verticalLayout_2.addWidget(self.label_2)
        self.widget2 = QtWidgets.QWidget(self.centralwidget)
        self.widget2.setGeometry(QtCore.QRect(20, 80, 220, 25))
        self.widget2.setObjectName("widget2")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.widget2)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pushButton = QtWidgets.QPushButton(self.widget2)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.widget2)
        self.pushButton_2.setObjectName("pushButton_2")
        self.horizontalLayout.addWidget(self.pushButton_2)
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Перевод грамм/ккалл"))
        self.label.setText(_translate("MainWindow", "КАЛОРИИ"))
        self.label_2.setText(_translate("MainWindow", "ГРАММЫ"))
        self.pushButton.setText(_translate("MainWindow", "Калории -> граммы"))
        self.pushButton_2.setText(_translate("MainWindow", "Граммы -> калории"))




class Calc(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("Калькулятор калорий")
        MainWindow.resize(586, 522)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.layoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.layoutWidget.setGeometry(QtCore.QRect(170, 82, 281, 161))
        self.layoutWidget.setObjectName("layoutWidget")
        self.horizontalLayout_6 = QtWidgets.QHBoxLayout(self.layoutWidget)
        self.horizontalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.Kolvo_kaloriy = QtWidgets.QLineEdit(self.layoutWidget)
        self.Kolvo_kaloriy.setFocusPolicy(QtCore.Qt.NoFocus)
        self.Kolvo_kaloriy.setObjectName("Kolvo_kaloriy")
        self.verticalLayout_2.addWidget(self.Kolvo_kaloriy)
        self.verticalLayout_7 = QtWidgets.QVBoxLayout()
        self.verticalLayout_7.setObjectName("verticalLayout_7")
        self.Age = QtWidgets.QSpinBox(self.layoutWidget)
        self.Age.setObjectName("Age")
        self.verticalLayout_7.addWidget(self.Age)
        self.ves = QtWidgets.QSpinBox(self.layoutWidget)
        self.ves.setObjectName("ves")
        self.verticalLayout_7.addWidget(self.ves)
        self.rost = QtWidgets.QSpinBox(self.layoutWidget)
        self.rost.setFocusPolicy(QtCore.Qt.NoFocus)
        self.rost.setMaximum(250)
        self.rost.setObjectName("rost")
        self.verticalLayout_7.addWidget(self.rost)
        self.floor_pol = QtWidgets.QComboBox(self.layoutWidget)
        self.floor_pol.setFocusPolicy(QtCore.Qt.NoFocus)
        self.floor_pol.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.floor_pol.setAcceptDrops(False)
        self.floor_pol.setWhatsThis("")
        self.floor_pol.setAccessibleName("")
        self.floor_pol.setEditable(True)
        self.floor_pol.setCurrentText("")
        self.floor_pol.setDuplicatesEnabled(False)
        self.floor_pol.setFrame(True)
        self.floor_pol.setObjectName("floor_pol")
        self.verticalLayout_7.addWidget(self.floor_pol)
        self.verticalLayout_2.addLayout(self.verticalLayout_7)
        self.horizontalLayout_6.addLayout(self.verticalLayout_2)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.vid_sporta = QtWidgets.QPushButton(self.layoutWidget)
        self.vid_sporta.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.vid_sporta.setAutoDefault(True)
        self.vid_sporta.setDefault(False)
        self.vid_sporta.setFlat(False)
        self.vid_sporta.setObjectName("vid_sporta")
        self.verticalLayout.addWidget(self.vid_sporta)
        self.vid_sporta_2 = QtWidgets.QPushButton(self.layoutWidget)
        self.vid_sporta_2.setObjectName("vid_sporta_2")
        self.verticalLayout.addWidget(self.vid_sporta_2)
        self.horizontalLayout_6.addLayout(self.verticalLayout)
        self.layoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.layoutWidget_2.setGeometry(QtCore.QRect(170, 240, 281, 51))
        self.layoutWidget_2.setObjectName("layoutWidget_2")
        self.horizontalLayout_7 = QtWidgets.QHBoxLayout(self.layoutWidget_2)
        self.horizontalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_7.setObjectName("horizontalLayout_7")
        self.pushButton = QtWidgets.QPushButton(self.layoutWidget_2)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout_7.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.layoutWidget_2)
        self.pushButton_2.setObjectName("pushButton_2")
        self.horizontalLayout_7.addWidget(self.pushButton_2)
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(120, 92, 51, 20))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(110, 130, 61, 20))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(120, 209, 51, 20))
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(110, 157, 61, 20))
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(116, 183, 51, 20))
        self.label_5.setObjectName("label_5")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle("Калькулятор калорий")
        self.vid_sporta.setText(_translate("MainWindow", "Бег / Ходьба"))
        self.vid_sporta_2.setText(_translate("MainWindow", "Велосипед"))
        self.pushButton.setText(_translate("MainWindow", "Вычислить"))
        self.pushButton_2.setText(_translate("MainWindow", "Сброс"))
        self.label.setText(_translate("MainWindow", "Калории"))
        self.label_2.setText(_translate("MainWindow", "   Возраст"))
        self.label_3.setText(_translate("MainWindow", "    Пол"))
        self.label_4.setText(_translate("MainWindow", "       Вес"))
        self.label_5.setText(_translate("MainWindow", "     Рост"))


class Vel(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("Велосипед")
        MainWindow.resize(588, 473)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(110, 88, 51, 21))
        self.label.setObjectName("label")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(110, 115, 51, 20))
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(110, 140, 41, 21))
        self.label_4.setObjectName("label_4")
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(160, 90, 281, 71))
        self.widget.setObjectName("widget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.widget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.lineEdit_3 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.verticalLayout.addWidget(self.lineEdit_3)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.verticalLayout.addWidget(self.lineEdit_2)
        self.lineEdit_4 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.verticalLayout.addWidget(self.lineEdit_4)
        self.widget1 = QtWidgets.QWidget(self.centralwidget)
        self.widget1.setGeometry(QtCore.QRect(160, 160, 281, 51))
        self.widget1.setObjectName("widget1")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.widget1)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pushButton = QtWidgets.QPushButton(self.widget1)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.widget1)
        self.pushButton_2.setObjectName("pushButton_2")
        self.horizontalLayout.addWidget(self.pushButton_2)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 588, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Велосипед"))
        self.label.setText(_translate("MainWindow", "Калории"))
        self.label_3.setText(_translate("MainWindow", "  Время"))
        self.label_4.setText(_translate("MainWindow", "  Пульс"))
        self.pushButton.setText(_translate("MainWindow", "Вычислить"))
        self.pushButton_2.setText(_translate("MainWindow", "Сбросить"))


class HelpMenu(object):
    def setupUi(self, HelpMenu):
        HelpMenu.setObjectName("HelpMenu")
        HelpMenu.resize(540, 93)
        self.centralwidget = QtWidgets.QWidget(HelpMenu)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, -30, 521, 141))
        self.label.setObjectName("label")
        HelpMenu.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(HelpMenu)
        self.statusbar.setObjectName("statusbar")
        HelpMenu.setStatusBar(self.statusbar)

        self.retranslateUi(HelpMenu)
        QtCore.QMetaObject.connectSlotsByName(HelpMenu)

    def retranslateUi(self, HelpMenu):
        _translate = QtCore.QCoreApplication.translate
        HelpMenu.setWindowTitle(_translate("HelpMenu", "HelpMenu"))
        self.label.setText(_translate("HelpMenu", "Вас приветствует Новая Эра!\n"
                                                  "Добро пожаловать в наш калькулятор калорий.\n"
                                                  "Нажав на кнопку \"Спорт\", вы перейдёте в окно где можно посчитать кол-во созжённых калориях.\n"
                                                  "А нажав на кнопку \"Еда\", откроется окно где можно посчитать кол-во калорий в определённой еде."))


class FoodHelp(object):
    def setupUi(self, FoodHelp):
        FoodHelp.setObjectName("FoodHelp")
        FoodHelp.resize(500, 144)
        self.centralwidget = QtWidgets.QWidget(FoodHelp)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(10, 20, 491, 101))
        self.label.setObjectName("label")
        FoodHelp.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(FoodHelp)
        self.statusbar.setObjectName("statusbar")
        FoodHelp.setStatusBar(self.statusbar)

        self.retranslateUi(FoodHelp)
        QtCore.QMetaObject.connectSlotsByName(FoodHelp)

    def retranslateUi(self, FoodHelp):
        _translate = QtCore.QCoreApplication.translate
        FoodHelp.setWindowTitle(_translate("FoodHelp", "FoodHelp"))
        self.label.setText(_translate("FoodHelp", "Чтобы подсчитать кол-во калорий в еде надо сделать:\n"
                                                  "1. В разделе \"Продукт\" выбирете блюда или продукт который вы хотите.\n"
                                                  "2. Когда вы выбрали продукт, надо указать сколько грамм вы хотите съесть.\n"
                                                  "3. Нажмите вычислить.\n"
                                                  "Примечание:\n"
                                                  "Как только вы выбирете продукт у вас сразу покажутся цифры. Это указанно на 100 грамм."))


class BegHelp(object):
    def setupUi(self, BgHelp):
        BgHelp.setObjectName("BgHelp")
        BgHelp.resize(403, 136)
        self.centralwidget = QtWidgets.QWidget(BgHelp)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 20, 381, 131))
        self.label.setObjectName("label")
        BgHelp.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(BgHelp)
        self.statusbar.setObjectName("statusbar")
        BgHelp.setStatusBar(self.statusbar)

        self.retranslateUi(BgHelp)
        QtCore.QMetaObject.connectSlotsByName(BgHelp)

    def retranslateUi(self, BgHelp):
        _translate = QtCore.QCoreApplication.translate
        BgHelp.setWindowTitle(_translate("BgHelp", "BegHelp"))
        self.label.setText(_translate("BgHelp", "Если вы хотите узнать, сжигаемы калории при беге, то сделайте далее:\n"
                                                "1. В строке \"Растояние\" введите растояние, которое вы пробежали.\n"
                                                "2. Введите время за которое вы пробежали это растояние.\n"
                                                "Примечание:\n"
                                                "Время вводится в минутах."))


class SportHelp(object):
    def setupUi(self, SpH):
        SpH.setObjectName("SpH")
        SpH.resize(314, 153)
        self.centralwidget = QtWidgets.QWidget(SpH)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(10, 10, 341, 141))
        self.label.setObjectName("label")
        SpH.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(SpH)
        self.statusbar.setObjectName("statusbar")
        SpH.setStatusBar(self.statusbar)

        self.retranslateUi(SpH)
        QtCore.QMetaObject.connectSlotsByName(SpH)

    def retranslateUi(self, SpH):
        _translate = QtCore.QCoreApplication.translate
        SpH.setWindowTitle(_translate("SpH", "SportHelp"))
        self.label.setText(_translate("SpH", "Что-бы подсчитать кол-во созжённых калорий, надо:\n"
                                             "1. В строке \"Возраст\" ввести сколько вам полных лет.\n"
                                             "2. Далее введите свой вес и рост.\n"
                                             "3. Выбирете свой пол.\n"
                                             "4. И нажмите на вид спорта который вам нужен."))


class PlHelp(object):
    def setupUi(self, PlHelp):
        PlHelp.setObjectName("PlHelp")
        PlHelp.resize(331, 137)
        self.centralwidget = QtWidgets.QWidget(PlHelp)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(10, -40, 471, 241))
        self.label.setObjectName("label")
        PlHelp.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(PlHelp)
        self.statusbar.setObjectName("statusbar")
        PlHelp.setStatusBar(self.statusbar)

        self.retranslateUi(PlHelp)
        QtCore.QMetaObject.connectSlotsByName(PlHelp)

    def retranslateUi(self, PlHelp):
        _translate = QtCore.QCoreApplication.translate
        PlHelp.setWindowTitle(_translate("PlHelp", "PlavanyeHelp"))
        self.label.setText(_translate("PlHelp", "Если надо расчитать созжённые калории при плавание, то:\n"
                                                "1. Введите дистанцию которую вы проплыли.\n"
                                                "2. Введите время за которое вы проплыли дистанцию.\n"
                                                "Примечание:\n"
                                                "Время вводится в минутах."))

class VelHelp(object):
    def setupUi(self, VelH):
        VelH.setObjectName("VelH")
        VelH.resize(416, 166)
        self.centralwidget = QtWidgets.QWidget(VelH)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 20, 391, 111))
        self.label.setObjectName("label")
        VelH.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(VelH)
        self.statusbar.setObjectName("statusbar")
        VelH.setStatusBar(self.statusbar)

        self.retranslateUi(VelH)
        QtCore.QMetaObject.connectSlotsByName(VelH)

    def retranslateUi(self, VelH):
        _translate = QtCore.QCoreApplication.translate
        VelH.setWindowTitle(_translate("VelH", "VelHelp"))
        self.label.setText(_translate("VelH", "  \n"
"Если надо расчитать созжённые калории при езде на велосипеде, то:\n"
"1. Надо ввести время, за которое вы проехали определённую дастанцию.\n"
"2. И ввести пуль, которы прослеживался у вас на протяжение всей езды.\n"
"Примечание:\n"
"Время вводится в минутах."))